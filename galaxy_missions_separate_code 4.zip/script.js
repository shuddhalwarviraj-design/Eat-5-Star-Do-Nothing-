const $=s=>document.querySelector(s),K={},clamp=(v,a,b)=>Math.max(a,Math.min(b,v)),rnd=(a=1)=>Math.random()*a;
let S={ship:0,diff:1,mute:false,vol:.5,ach:{},lb:[],win:{}};
try{Object.assign(S,JSON.parse(localStorage.getItem('gm')||'{}'))}catch(e){}
const save=()=>{try{localStorage.setItem('gm',JSON.stringify(S))}catch(e){}};
const GAMES=[{id:'dodge',n:'ASTEROID DODGE',d:'Survive 60s in a rock storm.',c:'#cbd5e1,#475569'},{id:'moon',n:'MOON LANDING',d:'Land softly on the green pad.',c:'#e5e7eb,#6b7280'},{id:'explore',n:'GALAXY EXPLORER',d:'Fly the solar system, learn facts.',c:'#fbbf24,#b45309'},{id:'collect',n:'SPACE COLLECTOR',d:'Grab crystals, avoid mines.',c:'#67e8f9,#7c3aed'}];
const SHIPS=[{n:'FALCON',c:0x38bdf8,spd:1,hp:1},{n:'NOVA',c:0xa855f7,spd:1.2,hp:.8},{n:'TITAN',c:0xf59e0b,spd:.85,hp:1.4}];
const ACH={fly:'First Flight',dodge:'Asteroid Survivor',land:'Soft Landing',explore:'Cosmic Explorer',collect:'Crystal Hunter (150+)',hard:'Hard Mode Hero'};
/* ---------- AUDIO ---------- */
let AC,MG;
function ainit(){if(AC)return;try{AC=new(window.AudioContext||window.webkitAudioContext)();MG=AC.createGain();MG.gain.value=S.mute?0:S.vol;MG.connect(AC.destination);music()}catch(e){}}
function sfx(f,d=.15,t='sine',v=.25){if(!AC||S.mute)return;const o=AC.createOscillator(),g=AC.createGain();o.type=t;o.frequency.value=f;g.gain.setValueAtTime(v,AC.currentTime);g.gain.exponentialRampToValueAtTime(.001,AC.currentTime+d);o.connect(g);g.connect(MG);o.start();o.stop(AC.currentTime+d)}
function music(){const n=[110,130.8,164.8,196,164.8,130.8];let i=0;setInterval(()=>{if(!AC||S.mute)return;const o=AC.createOscillator(),g=AC.createGain(),t=AC.currentTime;o.type='triangle';o.frequency.value=n[i%6]*(i%12<6?1:1.5);i++;g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(.12,t+.8);g.gain.linearRampToValueAtTime(0,t+2.4);o.connect(g);g.connect(MG);o.start();o.stop(t+2.5)},1200)}
function sync(){document.querySelectorAll('.mute').forEach(b=>b.textContent=S.mute?'🔇 MUTED':'🔊 SOUND');document.querySelectorAll('.vol').forEach(v=>v.value=S.vol*100);if(MG)MG.gain.value=S.mute?0:S.vol;save()}
/* ---------- THREE SETUP ---------- */
const R=new THREE.WebGLRenderer({antialias:true});R.setPixelRatio(Math.min(devicePixelRatio,2));document.body.prepend(R.domElement);
const cam=new THREE.PerspectiveCamera(60,1,.1,2500);
function rs(){R.setSize(innerWidth,innerHeight);cam.aspect=innerWidth/innerHeight;cam.updateProjectionMatrix()}addEventListener('resize',rs);rs();
const M=(c,o={})=>new THREE.MeshStandardMaterial(Object.assign({color:c,roughness:.6,metalness:.3},o));
function glowTex(c){const k=document.createElement('canvas');k.width=k.height=128;const x=k.getContext('2d'),g=x.createRadialGradient(64,64,0,64,64,64);g.addColorStop(0,c);g.addColorStop(1,'rgba(0,0,0,0)');x.fillStyle=g;x.fillRect(0,0,128,128);return new THREE.CanvasTexture(k)}
function glow(c,s){const o=new THREE.Sprite(new THREE.SpriteMaterial({map:glowTex(c),blending:THREE.AdditiveBlending,depthWrite:false}));o.scale.set(s,s,1);return o}
function ptex(a,b){const k=document.createElement('canvas');k.width=256;k.height=128;const x=k.getContext('2d');x.fillStyle=a;x.fillRect(0,0,256,128);for(let i=0;i<240;i++){x.globalAlpha=.25;x.fillStyle=Math.random()<.5?b:'#000';x.beginPath();x.ellipse(rnd(256),rnd(128),10+rnd(40),2+rnd(9),0,0,7);x.fill()}return new THREE.CanvasTexture(k)}
function space(sc,n=1500){const g=new THREE.BufferGeometry(),a=new Float32Array(n*3);for(let i=0;i<n*3;i++)a[i]=(Math.random()-.5)*1400;g.setAttribute('position',new THREE.BufferAttribute(a,3));const st=new THREE.Points(g,new THREE.PointsMaterial({size:1.5,color:0xffffff,sizeAttenuation:false}));sc.add(st);
[['rgba(99,102,241,.5)',[-250,80,-500]],['rgba(168,85,247,.5)',[300,-90,-550]],['rgba(56,189,248,.4)',[0,180,-600]]].forEach(([c,p])=>{const s=glow(c,600);s.position.set(...p);st.add(s)});
sc.add(new THREE.AmbientLight(0x7780bb,.8));const l=new THREE.DirectionalLight(0xffffff,1.1);l.position.set(5,10,7);sc.add(l);return st}
function ship(i){const g=new THREE.Group(),c=SHIPS[i].c,m=M(c,{metalness:.8,roughness:.3,emissive:c,emissiveIntensity:.2}),d=M(0x2a2a3c),add=(geo,mat,f)=>{const o=new THREE.Mesh(geo,mat);f&&f(o);g.add(o);return o};
if(i==0){add(new THREE.ConeGeometry(.5,2.4,12),m,o=>o.rotation.x=-Math.PI/2);add(new THREE.BoxGeometry(2.6,.08,.9),d,o=>o.position.z=.5)}
else if(i==1){add(new THREE.SphereGeometry(.6,16,12),m,o=>o.scale.z=2.2);add(new THREE.TorusGeometry(1.1,.08,8,24),d)}
else{add(new THREE.BoxGeometry(1.1,.6,2.2),m);[-1,1].forEach(s=>add(new THREE.CylinderGeometry(.25,.25,1.8,8),d,o=>{o.rotation.x=Math.PI/2;o.position.set(s*.9,0,.2)}))}
const f=add(new THREE.ConeGeometry(.25,1,8),new THREE.MeshBasicMaterial({color:0x66ccff}),o=>{o.rotation.x=Math.PI/2;o.position.z=1.7});f.name='fl';return g}
/* ---------- STATE / UI ---------- */
let sc,stars,G=null,menu,paused=false;const clock=new THREE.Clock();
const show=id=>{document.querySelectorAll('.scr').forEach(e=>e.classList.toggle('on',e.id==id));if(menu)menu.tx=id=='ships'||innerWidth<800?0:-5};
const hudOn=b=>{['#hud','#touch'].forEach(s=>$(s).classList.toggle('on',b));document.body.classList.toggle('game',b);if(!b)['#msg','#fact'].forEach(s=>$(s).style.display='none')};
const stat=o=>$('#stats').innerHTML=Object.entries(o).map(([k,v])=>`<span>${k} <b>${v}</b></span>`).join('');
const msg=t=>{$('#msg').style.display='block';$('#msg').textContent=t};
let tt;const toast=t=>{const e=$('#toast');e.textContent=t;e.style.display='block';clearTimeout(tt);tt=setTimeout(()=>e.style.display='none',2600)};
function modal(t,h,b){$('#mt').textContent=t;$('#mb').innerHTML=h;const e=$('#mbtn');e.innerHTML='';b.forEach(([l,f])=>{const x=document.createElement('button');x.className='btn sm';x.textContent=l;x.onclick=()=>{show(null);f()};e.appendChild(x)});show('modal');sync()}
function ach(k){if(!S.ach[k]){S.ach[k]=1;save();toast('🏆 '+ACH[k]);sfx(880,.4,'triangle')}}
function renderSel(){const w=Object.keys(S.win).length;$('#prog').style.width=w*25+'%';$('#pt').textContent=w+'/4 MISSIONS COMPLETE';
$('#cards').innerHTML=GAMES.map(g=>`<div class="glass card" data-g="${g.id}"><div class="orb" style="background:radial-gradient(circle at 30% 30%,${g.c})"></div><b>${g.n}</b><small>${g.d}</small><small>${S.win[g.id]?'✔ COMPLETED':'Not completed'}</small></div>`).join('');
document.querySelectorAll('[data-d]').forEach(b=>b.classList.toggle('off',+b.dataset.d!=S.diff))}
function renderShips(){$('#shipc').innerHTML=SHIPS.map((s,i)=>`<div class="glass card ${i==S.ship?'sel':''}" data-s="${i}"><b>${s.n}</b><small>Speed</small><div class="bar"><i style="width:${s.spd*70}%"></i></div><small>Armor</small><div class="bar"><i style="width:${s.hp*60}%"></i></div></div>`).join('');document.querySelectorAll('#shipc .bar i').forEach(i=>i.style.transition='none')}
async function lb(){let rows=null;if(DB){try{const q=await Promise.race([DB.collection('scores').orderBy('s','desc').limit(10).get(),new Promise((_,r)=>setTimeout(r,4000))]);rows=q.docs.map(d=>d.data())}catch(e){}}
const esc=v=>String(v).replace(/[<>&"]/g,''),gn=id=>(GAMES.find(g=>g.id==id)||{n:'?'}).n,dn=d=>['EASY','MED','HARD'][d]||'';
const list=rows?rows.map((e,i)=>`${i+1}. ${esc(e.n)} — ${gn(e.g)} ${esc(e.s)} (${dn(e.d)})`):S.lb.map((e,i)=>`${i+1}. ${gn(e.g)} — ${e.s} (${dn(e.d)})`);
modal('TROPHIES',Object.keys(ACH).map(k=>`${S.ach[k]?'✔':'○'} ${ACH[k]}`).join('<br>')+`<hr style="opacity:.3">${rows?'GLOBAL':'LOCAL'} TOP SCORES<br>`+(list.length?list.join('<br>'):'No scores yet.'),[['BACK',()=>show('home')]])}
function pause(){if(!G||G.over)return;if(paused){paused=false;show(null);return}paused=true;modal('PAUSED','<button class="btn sm mute"></button> <input class="vol" type="range" min="0" max="100">',[['RESUME',()=>paused=false],['RESTART',()=>start(G.id)],['EXIT',exit]])}
function exit(){G=null;paused=false;hudOn(0);menuScene();renderSel();show('sel')}
function endGame(win,txt){if(G.over)return;G.over=true;const id=G.id,s=Math.floor(G.score);hudOn(0);
if(win){S.win[id]=1;sfx(660,.6,'triangle');ach({dodge:'dodge',moon:'land',explore:'explore',collect:'collect'}[id]=='collect'?(s>=150?'collect':'fly'):{dodge:'dodge',moon:'land',explore:'explore'}[id]);if(S.diff==2)ach('hard')}else sfx(90,.7,'sawtooth');
S.lb.push({g:id,s,d:S.diff});S.lb.sort((a,b)=>b.s-a.s);S.lb=S.lb.slice(0,8);save();if(DB&&s>0)DB.collection('scores').add({n:S.name||'PILOT',g:id,s,d:S.diff,t:Date.now()}).catch(()=>{});
modal(win?'MISSION COMPLETE':'MISSION FAILED',`${txt}<br>SCORE <b>${s}</b>`,[['RETRY',()=>start(id)],['MENU',exit]])}
function start(id){ainit();G={id,score:0,over:false};paused=false;show(null);hudOn(1);G.upd=({dodge:()=>runner(0),collect:()=>runner(1),moon,explore})[id]();ach('fly')}
/* ---------- MENU SCENE ---------- */
function menuScene(){G=null;sc=new THREE.Scene();stars=space(sc);
const p=new THREE.Mesh(new THREE.SphereGeometry(7,48,32),new THREE.MeshStandardMaterial({map:ptex('#1e40af','#22d3ee'),roughness:.8}));p.position.set(12,-3,-25);p.add(glow('rgba(56,189,248,.55)',26));sc.add(p);
const sat=new THREE.Group();sat.add(new THREE.Mesh(new THREE.BoxGeometry(.8,.8,1.2),M(0xcccccc)));[-1,1].forEach(s=>{const w=new THREE.Mesh(new THREE.BoxGeometry(1.6,.05,.8),M(0x2563eb,{emissive:0x1d4ed8,emissiveIntensity:.5}));w.position.x=s*1.3;sat.add(w)});sc.add(sat);
const ast=[];for(let i=0;i<14;i++){const a=new THREE.Mesh(new THREE.IcosahedronGeometry(.3+rnd(.8),1),M(0x7a6f68,{flatShading:true,roughness:1}));a.position.set((Math.random()-.5)*40,(Math.random()-.5)*16,-rnd(30));sc.add(a);ast.push(a)}
menu={tx:-5,t:0,sh:null};cam.position.set(0,0,10);cam.lookAt(0,0,0);setMenuShip();
menu.upd=dt=>{menu.t+=dt;p.rotation.y+=dt*.05;sat.position.set(Math.cos(menu.t*.4)*14+6,Math.sin(menu.t*.3)*3+3,Math.sin(menu.t*.4)*8-12);sat.rotation.y+=dt;ast.forEach((a,i)=>{a.rotation.x+=dt*.3;a.rotation.y+=dt*.2;a.position.x+=dt*(.4+i%3*.2);if(a.position.x>22)a.position.x=-22});const s=menu.sh;s.rotation.y+=dt*.7;s.position.x+=(menu.tx-s.position.x)*dt*3;s.position.y=Math.sin(menu.t*1.5)*.3;s.getObjectByName('fl').scale.y=.8+rnd(.5)}}
function setMenuShip(){if(menu.sh)sc.remove(menu.sh);menu.sh=ship(S.ship);menu.sh.scale.setScalar(1.7);menu.sh.position.x=menu.tx;sc.add(menu.sh)}
/* ---------- GAME 1 & 4: RUNNER ---------- */
function runner(col){
const T=col?45:60,D=[.7,1,1.4][S.diff],sp=SHIPS[S.ship];let lives=Math.max(1,Math.round(3*sp.hp)+1-S.diff),t=0,sT=0,inv=0,vx=0,vy=0;
sc=new THREE.Scene();stars=space(sc);const pl=ship(S.ship);sc.add(pl);cam.position.set(0,2,9);
const rock=new THREE.IcosahedronGeometry(1,1),rm=M(0x8a7f78,{flatShading:true,roughness:1}),cg=new THREE.OctahedronGeometry(.7),cm=new THREE.MeshStandardMaterial({color:0x22d3ee,emissive:0x06b6d4,emissiveIntensity:1.3}),mg=new THREE.DodecahedronGeometry(1),mm=M(0xef4444,{emissive:0x7f1d1d,flatShading:true}),O=[];
msg(col?'Collect cyan crystals (+10), avoid red mines. Arrows / WASD / touch pad. Need 100+ points.':'Dodge the asteroids for 60 seconds. Arrows / WASD / touch pad.');
return dt=>{t+=dt;sT-=dt;inv-=dt;const dir=(a,b,c,d)=>(K[a]||K[b]?1:0)-(K[c]||K[d]?1:0),s=16*sp.spd;
vx+=(dir('ArrowRight','KeyD','ArrowLeft','KeyA')*s-vx)*Math.min(1,dt*6);vy+=(dir('ArrowUp','KeyW','ArrowDown','KeyS')*s-vy)*Math.min(1,dt*6);
pl.position.x=clamp(pl.position.x+vx*dt,-11,11);pl.position.y=clamp(pl.position.y+vy*dt,-6,6);pl.rotation.z=-vx*.04;pl.rotation.x=vy*.02;pl.getObjectByName('fl').scale.y=.8+rnd(.5);pl.visible=inv<=0||Math.floor(t*14)%2==0;
cam.position.x+=(pl.position.x*.6-cam.position.x)*dt*3;cam.position.y=pl.position.y*.5+2;cam.lookAt(pl.position.x*.5,pl.position.y*.5,-20);
if(!col)G.score+=dt*10;
if(sT<=0){sT=Math.max(.16,.5/D);const crys=col&&Math.random()<.5,m=new THREE.Mesh(crys?cg:col?mg:rock,crys?cm:col?mm:rm),r=crys?.8:.8+rnd(1.3);m.scale.setScalar(crys?1:r);if(!crys)m.scale.y*=.7+rnd(.6);
m.position.set(Math.random()<.4?pl.position.x+(Math.random()-.5)*4:(Math.random()-.5)*22,Math.random()<.4?pl.position.y+(Math.random()-.5)*3:(Math.random()-.5)*12,-130);sc.add(m);O.push({m,r:crys?.9:r*.85,v:(34+t*.4)*D*(.8+rnd(.4)),c:crys,sp:rnd(2)})}
for(let i=O.length-1;i>=0;i--){const o=O[i];o.m.position.z+=o.v*dt;o.m.rotation.x+=dt*o.sp;o.m.rotation.y+=dt;let rm_=false;
if(o.m.position.distanceTo(pl.position)<o.r+.9){if(o.c){G.score+=10;sfx(900+rnd(300),.12,'triangle');rm_=true}else if(inv<=0){lives--;inv=1.5;sfx(110,.35,'sawtooth',.35);rm_=true}}
if(o.m.position.z>10){rm_=true;if(!o.c&&!col)G.score+=3}
if(rm_){sc.remove(o.m);O.splice(i,1)}}
stat({SCORE:Math.floor(G.score),TIME:Math.max(0,T-t).toFixed(1)+'s',SHIELD:lives});
if(lives<=0)endGame(false,'Hull destroyed.');else if(t>=T){if(col&&G.score<100)endGame(false,'Time up — you needed 100 points.');else endGame(true,'You survived the mission!')}}}
/* ---------- GAME 2: MOON LANDING ---------- */
function moon(){
const D=[.7,1,1.4][S.diff],lim=[4.5,3.5,2.5][S.diff],sp=SHIPS[S.ship],H=1.45;sc=new THREE.Scene();stars=space(sc,900);
const gr=new THREE.Mesh(new THREE.PlaneGeometry(800,140),M(0x8c8c94,{roughness:1,metalness:0}));gr.rotation.x=-Math.PI/2;sc.add(gr);
for(let i=0;i<90;i++){const r=new THREE.Mesh(new THREE.IcosahedronGeometry(.2+rnd(1.2),0),M(0x6b6b73,{flatShading:true}));r.position.set((Math.random()-.5)*320,.1,-rnd(50));sc.add(r)}
for(let i=0;i<28;i++){const c=new THREE.Mesh(new THREE.RingGeometry(2,3+rnd(4),24),new THREE.MeshBasicMaterial({color:0x55555c,side:2}));c.rotation.x=-Math.PI/2;c.position.set((Math.random()-.5)*320,.03,-rnd(40));sc.add(c)}
const px=(Math.random()<.5?-1:1)*(14+rnd(26)),pf=new THREE.Mesh(new THREE.CylinderGeometry(4.5,4.5,.4,32),M(0x22c55e,{emissive:0x16a34a,emissiveIntensity:.9}));pf.position.set(px,.2,0);sc.add(pf);
const bc=glow('rgba(34,197,94,.8)',14);bc.position.set(px,2,0);sc.add(bc);
const earth=new THREE.Mesh(new THREE.SphereGeometry(10,32,24),new THREE.MeshStandardMaterial({map:ptex('#1d4ed8','#16a34a')}));earth.position.set(-60,60,-200);sc.add(earth);
const L=new THREE.Group();L.add(new THREE.Mesh(new THREE.CylinderGeometry(.8,1,1.4,12),M(0xd4d4d8,{metalness:.8})));
const top=new THREE.Mesh(new THREE.SphereGeometry(.8,12,8,0,6.3,0,1.6),M(sp.c,{emissive:sp.c,emissiveIntensity:.4}));top.position.y=.7;L.add(top);
[-1,1].forEach(s=>{const l=new THREE.Mesh(new THREE.BoxGeometry(.1,1.5,.1),M(0x999999));l.position.set(s*.9,-.8,0);l.rotation.z=s*.4;L.add(l)});
const fl=new THREE.Mesh(new THREE.ConeGeometry(.5,1.8,8),new THREE.MeshBasicMaterial({color:0xfbbf24}));fl.rotation.x=Math.PI;fl.position.y=-1.5;L.add(fl);sc.add(L);
let x=px+(Math.random()<.5?-1:1)*(15+rnd(15)),y=45,vx=(Math.random()-.5)*4,vy=0,a=0,fuel=100;
msg('Rotate: ←/→ or A/D. Thrust: Space / ↑ / W. Land upright and slowly on the green pad.');
return dt=>{const th=(K.Space||K.ArrowUp||K.KeyW)&&fuel>0;a+=((K.ArrowLeft||K.KeyA?1:0)-(K.ArrowRight||K.KeyD?1:0))*2*dt*sp.spd;
let ax=0,ay=-2.2;if(th){ax=-Math.sin(a)*7;ay+=Math.cos(a)*7;fuel=Math.max(0,fuel-14*D*dt);if(Math.random()<.15)sfx(80,.08,'sawtooth',.12)}
vx+=ax*dt;vy+=ay*dt;x+=vx*dt;y+=vy*dt;L.position.set(x,y,0);L.rotation.z=a;fl.visible=!!th;fl.scale.y=.7+rnd(.7);
cam.position.x+=(x-cam.position.x)*dt*3;cam.position.y=Math.max(6,y*.55+5);cam.position.z=26;cam.lookAt(cam.position.x,cam.position.y-3,0);
const v=Math.hypot(vx,vy),bad=v>lim;G.score=Math.round(fuel*8);
stat({FUEL:Math.round(fuel)+'%',SPEED:`<span style="color:${bad?'#f87171':'#4ade80'}">${v.toFixed(1)} m/s</span> (max ${lim})`,ALT:Math.max(0,y-H).toFixed(0)+'m',PAD:(px-x>0?'→ ':'← ')+Math.abs(px-x).toFixed(0)+'m'});
if(y-H<=0){const ok=!bad&&Math.abs(a)<.35&&Math.abs(x-px)<4.2;if(ok){G.score=Math.round(fuel*8+(lim-v)*150+300);endGame(true,`Perfect touchdown at ${v.toFixed(1)} m/s!`)}else endGame(false,Math.abs(x-px)>=4.2?'You missed the landing pad.':bad?`Crashed at ${v.toFixed(1)} m/s (max ${lim}).`:'Lander tipped over.')}
else if(Math.abs(x)>180||y>140)endGame(false,'Lost in space.')}}
/* ---------- GAME 3: GALAXY EXPLORER ---------- */
const PL=[['Mercury','#8c857d','#5e574f',1.6,40,'Smallest planet. A year lasts just 88 Earth days.'],['Venus','#d9a441','#b5762a',3.2,62,'Hottest planet (~465°C), wrapped in thick acid clouds.'],['Earth','#1d4ed8','#16a34a',3.4,86,'Our home: the only known world with life and liquid oceans.'],['Mars','#c1440e','#8a2f0a',2.4,110,'The Red Planet hosts Olympus Mons, the tallest known volcano.'],['Jupiter','#c99b6b','#8f5f3a',9,165,'Largest planet. Its Great Red Spot storm is over 150 years old.'],['Saturn','#e3c98a','#b09660',7.5,220,'Famous for icy rings spanning about 280,000 km.'],['Uranus','#7dd3fc','#38bdf8',5,270,'An ice giant that rotates on its side.'],['Neptune','#2563eb','#1e3a8a',5,320,'Windiest world, with supersonic storms above 2,000 km/h.']];
const MIS=[['Inner Planets',[0,1,2,3]],['Gas Giants',[4,5]],['Ice Giants',[6,7]]];
function explore(){
const sp=SHIPS[S.ship],vr=[14,9,6][S.diff];sc=new THREE.Scene();stars=space(sc,2200);
const sun=new THREE.Mesh(new THREE.SphereGeometry(14,32,24),new THREE.MeshBasicMaterial({color:0xffaa22}));sun.add(glow('rgba(255,180,60,.8)',90));sc.add(sun,new THREE.PointLight(0xfff2cc,2.2));
const P=PL.map((d,i)=>{const m=new THREE.Mesh(new THREE.SphereGeometry(d[3],32,24),new THREE.MeshStandardMaterial({map:ptex(d[1],d[2]),roughness:.9}));
if(i==5){const r=new THREE.Mesh(new THREE.RingGeometry(d[3]*1.4,d[3]*2.3,48),new THREE.MeshBasicMaterial({color:0xcbb68a,side:2,transparent:true,opacity:.7}));r.rotation.x=Math.PI/2.3;m.add(r)}
const o=new THREE.Mesh(new THREE.RingGeometry(d[4]-.15,d[4]+.15,128),new THREE.MeshBasicMaterial({color:0x3b82f6,transparent:true,opacity:.22,side:2}));o.rotation.x=-Math.PI/2;sc.add(o,m);return{m,a:rnd(6.28),w:1.2/Math.pow(d[4],.9),d}});
const g=ship(S.ship);g.rotation.order='YXZ';g.position.set(0,6,36);sc.add(g);let yaw=0,pit=0,spd=0;const vis=new Set(),done=new Set();
msg('←/→ or A/D steer · ↑/↓ or W/S pitch · hold Space/THRUST to fly · Shift boosts. Visit all 8 planets.');
return dt=>{const dir=(a,b,c,d)=>(K[a]||K[b]?1:0)-(K[c]||K[d]?1:0);
yaw+=dir('ArrowLeft','KeyA','ArrowRight','KeyD')*1.6*dt*sp.spd;pit=clamp(pit+dir('ArrowUp','KeyW','ArrowDown','KeyS')*1.3*dt*sp.spd,-1.3,1.3);g.rotation.set(pit,yaw,0);
const mx=(K.ShiftLeft||K.ShiftRight?150:65)*sp.spd;spd=K.Space?Math.min(spd+70*dt,mx):spd*Math.max(0,1-dt*.7);
const f=new THREE.Vector3(0,0,-1).applyQuaternion(g.quaternion);g.position.addScaledVector(f,spd*dt);g.getObjectByName('fl').scale.y=.5+spd/40+rnd(.4);
let near=null;
P.forEach((p,i)=>{p.a+=p.w*dt;p.m.position.set(Math.cos(p.a)*p.d[4],0,Math.sin(p.a)*p.d[4]);p.m.rotation.y+=dt*.2;
const dv=g.position.clone().sub(p.m.position),l=dv.length(),r=p.d[3];if(l<r+1.8){g.position.copy(p.m.position).addScaledVector(dv.normalize(),r+1.8);spd*=.5}
if(l<r+vr&&!vis.has(i)){vis.add(i);G.score+=100;sfx(700,.3,'triangle');toast('Visited '+p.d[0]+'  +100');MIS.forEach(([n,ids],k)=>{if(!done.has(k)&&ids.every(j=>vis.has(j))){done.add(k);G.score+=300;setTimeout(()=>toast('MISSION DONE: '+n+'  +300'),1500)}})}
if(l<r*4+22&&(!near||l<near[1]))near=[p,l]});
{const dv=g.position.clone(),l=dv.length();if(l<16){g.position.copy(dv.normalize().multiplyScalar(16));spd*=.5}}
const fe=$('#fact');if(near){fe.style.display='block';fe.innerHTML=`<b>${near[0].d[0].toUpperCase()}</b>${vis.has(PL.indexOf(near[0].d))||near[0].d?'':''}<br>${near[0].d[5]}`}else fe.style.display='none';
const off=new THREE.Vector3(0,2.5,9).applyQuaternion(g.quaternion).add(g.position);cam.position.lerp(off,Math.min(1,dt*6));cam.lookAt(g.position.clone().addScaledVector(f,12));
const nm=MIS.find((m,k)=>!done.has(k));
stat({PLANETS:vis.size+'/8',SPEED:Math.round(spd),MISSION:nm?`${nm[0]} ${nm[1].filter(j=>vis.has(j)).length}/${nm[1].length}`:'Done',SCORE:G.score});
if(vis.size==8)endGame(true,'You explored the whole solar system!')}}
/* ---------- COSMIC BRAIN GAMES ---------- */
let brainMode="",memoryPattern=[],memoryInput=[],memoryLevel=3,memoryTimer=null;
function brainSetup(mode){
 brainMode=mode;$('#brainPlay').style.display='block';$('#brainFeedback').textContent='';$('#brainAnswers').innerHTML='';$('#memorySeq').textContent='';
 const title={memory:'MEMORY BLAST',puzzle:'NUMBER PUZZLE',chess:'CHESS BRAIN'}[mode];
 $('#brainTitle').textContent=title;
 if(mode==='memory'){
   $('#brainQuestion').textContent='Watch the sequence carefully, then repeat it by clicking the numbers in the same order.';
   memoryPattern=Array.from({length:memoryLevel},()=>1+Math.floor(Math.random()*4));memoryInput=[];
   $('#brainAnswers').innerHTML=[1,2,3,4].map(n=>`<button class="brain-answer" data-memory="${n}" style="display:inline-block;width:22%;margin:1%"> ${n} </button>`).join('');
   let i=0;$('#memorySeq').textContent='GET READY…';
   clearInterval(memoryTimer);memoryTimer=setInterval(()=>{if(i<memoryPattern.length){$('#memorySeq').textContent=memoryPattern[i];i++}else{clearInterval(memoryTimer);$('#memorySeq').textContent='YOUR TURN!'}},850);
 }else if(mode==='puzzle'){
   const puzzles=[{q:'What comes next? 2, 4, 8, 16, __',a:['18','24','32','36'],c:2,why:'Each number doubles. 16 × 2 = 32.'},{q:'I am an odd number. Remove one letter and I become even. What am I?',a:['Seven','Nine','Five','Eleven'],c:0,why:'Remove the “s” from seven and it becomes “even”.'},{q:'What comes next? 1, 1, 2, 3, 5, 8, __',a:['10','11','13','15'],c:2,why:'The Fibonacci pattern adds the previous two numbers: 5 + 8 = 13.'}];
   const q=puzzles[Math.floor(Math.random()*puzzles.length)];$('#brainQuestion').textContent=q.q;
   $('#brainAnswers').innerHTML=q.a.map((a,i)=>`<button class="brain-answer" data-answer="${i}">${a}</button>`).join('');
   $('#brainAnswers').dataset.correct=q.c;$('#brainAnswers').dataset.why=q.why;
 }else{
   const q={q:'Which chess piece moves in an L-shape?',a:['Bishop','Knight','Rook','Queen'],c:1,why:'The knight moves two squares in one direction and one square perpendicular.'};
   $('#brainQuestion').textContent=q.q;
   $('#brainAnswers').innerHTML=q.a.map((a,i)=>`<button class="brain-answer" data-answer="${i}">${a}</button>`).join('');
   $('#brainAnswers').dataset.correct=q.c;$('#brainAnswers').dataset.why=q.why;
 }
}
function brainResult(ok,why){$('#brainFeedback').textContent=(ok?'✅ Correct! ':'❌ Not quite. ')+why;if(ok)sfx(780,.2,'triangle');else sfx(160,.2,'sawtooth');}
document.addEventListener('click',e=>{
 const b=e.target.closest('[data-brain],[data-answer],[data-memory],#brainAgain');if(!b)return;
 if(b.hasAttribute('data-brain')){brainSetup(b.dataset.brain);return}
 if(b.id==='brainAgain'){if(brainMode==='memory'&&memoryInput.length===memoryPattern.length&&memoryLevel<8)memoryLevel++;brainSetup(brainMode);return}
 if(b.hasAttribute('data-answer')){const correct=Number($('#brainAnswers').dataset.correct)===Number(b.dataset.answer);brainResult(correct,$('#brainAnswers').dataset.why);return}
 if(b.hasAttribute('data-memory')){
   if($('#memorySeq').textContent!=='YOUR TURN!')return;
   memoryInput.push(Number(b.dataset.memory));const i=memoryInput.length-1;
   if(memoryInput[i]!==memoryPattern[i]){brainResult(false,'The sequence was '+memoryPattern.join(' · ')+'. Press PLAY AGAIN to retry.');return}
   if(memoryInput.length===memoryPattern.length){brainResult(true,'Great memory! You completed level '+memoryLevel+'.');}
   else $('#brainFeedback').textContent='Correct so far: '+memoryInput.length+'/'+memoryPattern.length;
 }
});
/* ---------- INPUT & EVENTS ---------- */
addEventListener('keydown',e=>{if(e.target.id=='pn')return;K[e.code]=1;if(['Space','ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.code))e.preventDefault();if(e.code=='KeyP'||e.code=='Escape')pause();if(e.code=='KeyM'){S.mute=!S.mute;sync()}});
addEventListener('keyup',e=>K[e.code]=0);addEventListener('blur',()=>{for(const k in K)K[k]=0;if(G&&!G.over&&!paused)pause()});
document.querySelectorAll('[data-k]').forEach(b=>{const on=v=>e=>{e.preventDefault();K[b.dataset.k]=v};b.addEventListener('pointerdown',on(1));['pointerup','pointerleave','pointercancel'].forEach(t=>b.addEventListener(t,on(0)))});
document.addEventListener('pointerdown',ainit);
document.addEventListener('input',e=>{if(e.target.classList.contains('vol')){S.vol=e.target.value/100;sync()}});
document.addEventListener('click',e=>{const t=e.target.closest('[data-go],[data-g],[data-d],[data-s],[data-a],.mute');if(!t)return;ainit();sfx(500,.08,'square',.1);const d=t.dataset;
if(t.classList.contains('mute')){S.mute=!S.mute;sync()}
else if(d.go)d.go=='lb'?lb():(show(d.go),d.go=='sel'&&renderSel());
else if(d.g)start(d.g);
else if(d.d){S.diff=+d.d;save();renderSel()}
else if(d.s){S.ship=+d.s;save();setMenuShip();renderShips()}
else if(d.a=='p')pause();else if(d.a=='r'&&G)start(G.id);else if(d.a=='x')exit()});
/* ---------- LOOP ---------- */
function loop(){requestAnimationFrame(loop);const dt=Math.min(clock.getDelta(),.05);if(G){if(!paused&&!G.over)G.upd(dt)}else menu.upd(dt);stars.position.copy(cam.position);R.render(sc,cam)}
let DB=null;
try{window.claude&&claude.use('db').then(d=>DB=d).catch(()=>{})}catch(e){}
$('#pn').value=S.name||'';$('#pn').addEventListener('input',e=>{S.name=e.target.value.replace(/[<>&"]/g,'').trim().slice(0,12);save()});
menuScene();renderSel();renderShips();sync();loop();
let ld=0;const li=setInterval(()=>{ld+=4+rnd(14);$('#bar').style.width=Math.min(ld,100)+'%';if(ld>=100){clearInterval(li);$('#load').style.opacity=0;setTimeout(()=>{$('#load').remove();show('home')},600)}},120);
